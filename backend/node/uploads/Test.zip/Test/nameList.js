const yolo_classes = [
    "ข้าวผัดไข่",
    "ข้าวผัด",
    "ไข่เจียว",
    "ผัดกระเพรา"
  ];

exports.yolo_classes = yolo_classes